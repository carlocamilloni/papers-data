Examples to perform simple SAXS refinement using Martini Beads form factors.
The python script can be use to simplify the generation of the mapping from atomistic to martini
