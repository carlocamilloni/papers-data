Here are included the starting configurations, topology, force field
parameter files and plumed input files to perform metadynamic metainference
simulations of b2-microglobulin as reported in the reference paper.

REFERENCE: Achour, et al. (under review) 
