Here are included the thermalised structures used to start the simulations,
the gromacs topology, force field and simulations parameters as well as the plumed2 input file.

REFERENCE: Weber, et al. "The Antibody Light-Chain Linker Regulates Domain Orientation and Amyloidogenicity" JMB
https://doi.org/10.1016/j.jmb.2018.10.024


